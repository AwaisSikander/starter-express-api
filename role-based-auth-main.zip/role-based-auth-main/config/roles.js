const ROLE = {
  superadmin: "superadmin",
  admin: "admin",
  user: "user",
};

module.exports = { ROLE };
